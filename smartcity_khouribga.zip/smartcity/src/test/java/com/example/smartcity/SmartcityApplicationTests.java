package com.example.smartcity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartcityApplicationTests {

	@Test
	void contextLoads() {
	}

}
